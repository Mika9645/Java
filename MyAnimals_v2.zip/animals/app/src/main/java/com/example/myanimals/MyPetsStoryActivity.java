package com.example.myanimals;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.health.connect.datatypes.units.Length;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MyPetsStoryActivity extends AppCompatActivity implements View.OnClickListener{
    private Button btMore;
    private ImageView ivPic;
    private TextView tvStory;
    private final int length=3;

    private ArrayList<Animal> myAnimalList = new ArrayList<Animal>();
    private ArrayList<Dog> myDogList = new ArrayList<Dog>();
    private ArrayList<Cat> myCatList = new ArrayList<Cat>();
    private ArrayList<Parrot> myParrotList = new ArrayList<Parrot>();
    private int[] counter;
    private static int size=0;
    private static int photoNum=0;
    private static String buttonType="";

    private final String  EXTRA_buttonDog="dog";
    private final String  EXTRA_buttonCat="cat";
    private final String  EXTRA_buttonAll="all";
    private final String  EXTRA_buttonParrot="parrot";
    private static String currentStory="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_pets_story);
        initViews();
        initObjects();
    }

    private void initObjects() {

        myDogList.add(new Dog("Oliver", "male", 4, "donestic", 5, "duchshund", 5,  "red", R.drawable.duch));
        myDogList.add(new Dog("Tay", "female" ,4 ,"Donestic" ,6, "Pomerian", 5, "white", R.drawable.taydog));
        myDogList.add(new Dog("Tofi", "female" ,4 ,"Donestic" ,1, "shitzu", 6, "white", R.drawable.shitzu));


        myCatList.add( new Cat ("max "," Female ", 4 ," Domestic ",  " Black ",R.drawable.blackcat));
        myCatList.add( new Cat ("robert ","Male", 4 ," Domestic ",  "Sandy Light ", R.drawable.whitecat)) ;
        myCatList.add(new Cat ("milly ","Male", 4 ," Domestic ", " Pure White ",R.drawable.gingicat));

        myParrotList.add( new Parrot ("pesto ","Male", 4 ," Domestic ", 3, "eclactus", "green", R.drawable.parrot));   ;
        myParrotList.add( new Parrot ("shmoolik ","Male", 4 ," Domestic ", 3, "eclactus", "green", R.drawable.secondparrot));   ;
        myParrotList.add( new Parrot ("aharon ","Male", 4 ," Domestic ", 3, "eclactus", "green", R.drawable.thirdparrot));   ;


        initArrayList();
        String str = "     I  am " + "\n";

        if (buttonType.equals(EXTRA_buttonDog)) {
            tvStory.setText(str + myDogList.get(photoNum).toString()); // to define the first image we see on the dogStoryActivity
            ivPic.setImageResource(myDogList.get(photoNum).getPicNumber());
        }
        else if (buttonType.equals(EXTRA_buttonCat)){
            tvStory.setText(str + myCatList.get(photoNum).toString());
            ivPic.setImageResource(myCatList.get(photoNum).getPicNumber());
        }
        else if (buttonType.equals(EXTRA_buttonParrot)){
            tvStory.setText(str + myParrotList.get(photoNum).toString());
            ivPic.setImageResource(myParrotList.get(photoNum).getPicNumber());
        }
        else if (buttonType.equals(EXTRA_buttonAll)) {
            tvStory.setText(str + myAnimalList.get(photoNum).toString());
            ivPic.setImageResource(myAnimalList.get(photoNum).getPicNumber());
        }
        photoNum=1;

    }


    private void initViews() {
        btMore=findViewById(R.id.btMore);
        btMore.setOnClickListener(this);
        ivPic=findViewById(R.id.ivPic);
        tvStory=findViewById(R.id.tvStory);
        buttonType=(String)getIntent().getExtras().get("buttonClicked");
    }

    private void initArrayList() {
        for (int i = 0; i < myDogList.size(); i++)
        {
            myAnimalList.add(myDogList.get(i));
        }
        for (int i = 0; i < myCatList.size(); i++)
        {
            myAnimalList.add(myCatList.get(i));
        }
        for (int i = 0; i < myParrotList.size(); i++)
        {
            myAnimalList.add(myParrotList.get(i));
        }

    }

    @Override
    public void onClick(View view) {
        if (view == btMore) {
            {
                if(buttonType.equals(EXTRA_buttonAll))
                {

                    tvStory.setText("     I  am " + "\n" + myAnimalList.get(photoNum).toString());
                    ivPic.setImageResource(myAnimalList.get(photoNum).getPicNumber());

                    if (photoNum == myAnimalList.size() - 1)
                        photoNum = 0;
                    else
                        photoNum += 1;
                }
                else if (buttonType.equals(EXTRA_buttonDog)) {
                    tvStory.setText("     I  am " + "\n" + myDogList.get(photoNum).toString());
                    ivPic.setImageResource(myDogList.get(photoNum).getPicNumber());

                    if (photoNum == myDogList.size() - 1)
                        photoNum = 0;
                    else
                        photoNum++;
                }else if (buttonType.equals(EXTRA_buttonParrot) || buttonType.equals(EXTRA_buttonAll)) {
                        tvStory.setText("     I  am " + "\n" + myParrotList.get(photoNum).toString());
                        ivPic.setImageResource(myParrotList.get(photoNum).getPicNumber());

                        if (photoNum == myParrotList.size() - 1)
                            photoNum = 0;
                        else
                            photoNum += 1;
                    }
                 else if (buttonType.equals(EXTRA_buttonCat) || buttonType.equals(EXTRA_buttonAll)) {
                    tvStory.setText("     I  am " + "\n" + myCatList.get(photoNum).toString());
                    ivPic.setImageResource(myCatList.get(photoNum).getPicNumber());

                    if (photoNum == myCatList.size() - 1)
                        photoNum = 0;
                    else
                        photoNum += 1;
                }

                currentStory= (String) tvStory.getText();
            }
        }
    }
    @Override
    public  boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_options,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        int id = item.getItemId();
        if(id==R.id.menuBack)
        {
            Toast.makeText(this, "You selected option back to main menu!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

        }
        else if(id==R.id.menuLogout)
        {
            Toast.makeText(this, "You selected log out, logging you out!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else if(id==R.id.menuSendGmail)
        {
            Toast.makeText(this, "You selected send data to gmail!!", Toast.LENGTH_SHORT).show();

        }
        else if(id==R.id.menuSendSms)
        {
            Toast.makeText(this, "You selected send data to SMS!", Toast.LENGTH_SHORT).show();

        }
        return true;
    }
}