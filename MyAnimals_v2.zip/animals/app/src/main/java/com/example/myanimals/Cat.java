package com.example.myanimals;

    public class Cat extends Animal{
    private String furColor;


        @Override
        public String toString() {
            return "a " + this.furColor + " cat " + ", my name is " + this.getName() + " and my gender is " + this.getGender();

        }

        public Cat(String name, String gender, int numOfLegs, String type, String furColor, int picNumber) {
        super(name, gender, numOfLegs, type,picNumber);
        this.furColor=furColor;
    }
    public String getFurColor() {
        return this.furColor;
    }

    public void setFurColor(String furColor) {
        this.furColor = furColor;
    }




}
