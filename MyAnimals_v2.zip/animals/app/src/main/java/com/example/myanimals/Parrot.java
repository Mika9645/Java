package com.example.myanimals;

public class Parrot extends Animal {
    private int age;
    private String breed;
    private String color;


    public Parrot(String name, String gender, int numOfLegs, String type, int age, String breed, String color, int picNumber) {
        super(name, gender, numOfLegs, type, picNumber);

        this.age = age;
        this.breed = breed;
        this.color = color;
    }

    public int getAge() {
        return age;
    }

    public String getBreed() {
        return breed;
    }

    public String getColor() {
        return color;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "an " + this.breed + " parrot " + ", my name is " + this.getName() + " and my gender is " + this.getGender();

    }
}

