package com.example.remotecontrol;


public class RemoteControl {
    private String mode;
    private int temperature;
    private int heatMax;
    private int coolMin;


    public RemoteControl(String mode, int temperature, int heatMax, int coolMin) {
        this.mode = mode;
        this.temperature = temperature;
        this.heatMax = heatMax;
        this.coolMin = coolMin;
        //this.heatMaxF = celsiusToFahrenheit(heatMax);
        //this.coolMinF = celsiusToFahrenheit(coolMin);
    }

    public RemoteControl(String mode, int temperature) {
        this.temperature = temperature;
        this.mode = mode;
        if (mode.equals("F")) {
            this.heatMax = 86;
            this.coolMin = 60;
        }
        if( mode.equals("C"))
        {
            this.heatMax = 30;
            this.coolMin = 16;
        }
    }

    public RemoteControl(int temperature) {
        this.mode = "C";
        this.temperature = temperature;
        this.heatMax = 30;
        this.coolMin = 16;
        //this.heatMaxF = celsiusToFahrenheit(heatMax);
        //this.coolMinF = celsiusToFahrenheit(coolMin);
    }

    public boolean isTemperatureValid() {
        boolean result = true;
        if ((mode.equals("C") && (this.temperature > heatMax || this.temperature < coolMin)) ||
                (mode.equals("F") && (this.temperature > heatMax || this.temperature < coolMin))) {
            result = false;
        }
        return result;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
        int temp = 0;
        if(this.mode.equals("F"))
        {
            temp = celsiusToFahrenheit(this.temperature);
            coolMin = 60; //16 in celsius
            heatMax = 86; // 30 in celsius
        }
        if(this.mode.equals("C"))
        {
            coolMin = 16;
            heatMax = 30;
            temp = fahrenheitToCelsius(this.temperature);

        }
        if(temp<=heatMax && temp>= coolMin)
        {
            this.temperature=temp;
        }
        else
            this.temperature = coolMin;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {

        this.temperature = temperature;
    }

    public int getHeatMax() {

        return heatMax;
    }

    public void setHeatMax(int heatMax) {
        this.heatMax = heatMax;

    }

    public int getCoolMin() {
        return coolMin;
    }

    public void setCoolMin(int coolMin) {
        this.coolMin = coolMin;
    }
    private int celsiusToFahrenheit(int celsius) {

        return (int) ((celsius * 9.0 / 5) + 32);
    }

    private int fahrenheitToCelsius(int fahrenheit) {
        return (int) ((fahrenheit - 32) * 5.0/9);
    }


}
