package com.example.remotecontrol;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView ivCool;
    private ImageButton ibutCelcius;
    private TextView tvCool;
    private TextView tvZero;
    private TextView tvHeat;
    private Button btPlus;
    private Button btMinus;
    private RemoteControl myControl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        initObjects();
    }

    private void initViews() {
        ivCool = findViewById(R.id.logo);
        tvCool = findViewById(R.id.tvCool);
        tvZero = findViewById(R.id.tvZero);
        tvHeat = findViewById(R.id.tvHeat);
        btPlus = findViewById(R.id.btPlus);
        btMinus = findViewById(R.id.btMinus);
        ibutCelcius = findViewById(R.id.btCelcius);

        btPlus.setOnClickListener(this);
        btMinus.setOnClickListener(this);
        ibutCelcius.setOnClickListener(this);
    }

    private void initObjects() {
        myControl = new RemoteControl("C", 16);
    }

    @Override
    public void onClick(View view) {
        if (view == btPlus) {
            incTemperature();
        } else if (view == btMinus) {
            decTemperature();
        } else if (view == ibutCelcius) {
            toggleMode();
        }
    }

    private void incTemperature() {
        int currentTemperature = myControl.getTemperature();
        if (currentTemperature < myControl.getHeatMax()) {
            myControl.setTemperature(currentTemperature + 1);
        }
        else
            myControl.setTemperature(myControl.getCoolMin());
        tvZero.setText(String.valueOf(myControl.getTemperature()));    }

    private void decTemperature() {
        int currentTemperature = myControl.getTemperature();
        if (currentTemperature > myControl.getCoolMin()) {
            myControl.setTemperature(currentTemperature - 1);
        }
        tvZero.setText(String.valueOf(myControl.getTemperature()));    }

    private void toggleMode() {
        if (myControl.getMode().equals("C")) {
            myControl.setMode("F");
            ibutCelcius.setImageResource(R.drawable.fahrenheit);
        } else {
            myControl.setMode("C");
            ibutCelcius.setImageResource(R.drawable.celsius);
        }
        tvZero.setText(String.valueOf(myControl.getTemperature()));
    }


}
