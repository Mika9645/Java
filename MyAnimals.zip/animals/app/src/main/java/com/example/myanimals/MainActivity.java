package com.example.myanimals;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btDog;
    private Button btCat;
    private Button btParrot;
    private Button btMoreStories;
    private EditText etName;
    private final String  EXTRA_buttonDog="dog";
    private final String  EXTRA_buttonCat="cat";
    private final String  EXTRA_buttonParrot= "parrot";
    private final String  EXTRA_buttonAll="all";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }

    private void initViews() {
        btDog= findViewById(R.id.btDogs);
        btCat= findViewById(R.id.btCat);
        btParrot= findViewById(R.id.btParrot);
        btMoreStories= findViewById(R.id.btMoreStories);
        etName= findViewById(R.id.etName);
        btDog.setOnClickListener(this);
        btCat.setOnClickListener(this);
        btMoreStories.setOnClickListener(this);
        btParrot.setOnClickListener(this);


    }


    @Override
    public void onClick(View view) {

        if (view == btDog) {
            Intent intent = new Intent(this, MyPetsStoryActivity.class);
            intent.putExtra("buttonClicked", EXTRA_buttonDog);
            startActivity(intent);
        } else if (view == btCat) {
            Intent intent = new Intent(this, MyPetsStoryActivity.class);
            intent.putExtra("buttonClicked", EXTRA_buttonCat);
            startActivity(intent);
        } else if (view == btParrot) {
            Intent intent = new Intent(this, MyPetsStoryActivity.class);
            intent.putExtra("buttonClicked", EXTRA_buttonParrot);
            startActivity(intent);
        } else if (view == btMoreStories) {
            Intent intent = new Intent(this, MyPetsStoryActivity.class);
            intent.putExtra("buttonClicked", EXTRA_buttonAll);
            startActivity(intent);
        }


    }
}
