package com.example.myremotecontrol;
public class RemoteControl
{
    private String mode;
    private int temperature;
    private int heatMax;
    private int coolMin;

    private int heatMaxF;

    private int coolMinF;

    public RemoteControl(String mode, int temperature, int heatMax, int coolMin){
        this.mode=mode;
        this.temperature=temperature;
        this.heatMax=heatMax;
        this.coolMin=coolMin;

    }
    public RemoteControl (String mode, int temperature){
        this.mode=mode;
        this.temperature=temperature;
        this.heatMax=50;
        this.coolMin=-50;
        this.coolMinF = -58;
        this.heatMaxF = 122;
    }
    public RemoteControl (int temperature){
        this.mode="C";
        this.temperature=temperature;
        this.heatMax=30;
        this.coolMin=16;
    }

    public void isTemperatureValid(){
        boolean result=true;
        if(this.mode.equals("C"))
        {

            if (this.temperature>heatMax) {
                this.temperature = heatMax;
            }
            if(this.temperature<coolMin)
            {
                this.temperature = coolMin;
            }
        }
        if(this.mode.equals("F"))
        {
            if (this.temperature>heatMaxF)
            {
                this.temperature = heatMaxF;
            }
            if(this.temperature<coolMinF)
            {
                this.temperature = coolMinF;
            }
        }
    }

    public boolean isModeValid(){
        boolean result=false;
        if (this.mode.equals("C") || this.mode.equals("F"))
            result=true;
        return result;
    }

    public void setTemperature(int temperature)
    {
        this.temperature = temperature;
    }

    public String getMode()
    {
        return this.mode;
    }
    public void setMode(String mode)
    {
        this.mode = mode;
    }
    public int convert()
    {
        if(this.mode.equals("F"))
        {
            this.temperature =(int) (this.temperature*(9.0/5.0))+32;

        }
        else {
            this.temperature = (int) ((this.temperature-32)*(5.0/9.0));

        }
        return this.temperature;
    }

    public int getTemperature() {
        return this.temperature;

    }
}