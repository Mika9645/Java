package com.example.myremotecontrol;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView ivCool;
    private ImageButton ibutCelcius;
    private TextView tvCool;
    private TextView tvZero;
    private TextView tvHeat;
    private Button btPlus;
    private Button btMinus;
    private static int count=0;
    private RemoteControl myControl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        initObjects();
    }
    private void initObjects() {
        myControl = new RemoteControl("C", 0);
    }


    private void initViews(){
        ivCool=findViewById(R.id.ivCoolMode);
        tvCool=findViewById(R.id.tvCool);
        tvZero=findViewById(R.id.tvZero);
        tvHeat=findViewById(R.id.tvHeat);
        btPlus=findViewById(R.id.btPlus);
        btMinus=findViewById(R.id.btMinus);
        btPlus.setOnClickListener(this);
        btMinus.setOnClickListener(this);
        ibutCelcius=findViewById(R.id.btCelcius);
        ibutCelcius.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view==btPlus){
            count++;
            myControl.setTemperature(count);
            myControl.isTemperatureValid();
            tvZero.setText(String.valueOf(myControl.getTemperature()));

        }
        else if (view==btMinus) {
            count--;
            myControl.setTemperature(count);
            myControl.isTemperatureValid();
            tvZero.setText(String.valueOf(myControl.getTemperature()));
        }
        else if (view==ibutCelcius)
        {
            myControl.setTemperature(count);
            if (myControl.getMode().equals("C"))
            {
                myControl.setMode("F");
                ibutCelcius.setImageResource(R.drawable.fahrenheit);
            }
            else
            {
                myControl.setMode("C");
                ibutCelcius.setImageResource(R.drawable.cel);
            }
            myControl.convert();
            count = myControl.getTemperature();
            tvZero.setText(String.valueOf(count));

        }


    }
}

