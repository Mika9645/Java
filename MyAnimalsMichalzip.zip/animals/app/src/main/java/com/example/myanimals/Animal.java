package com.example.myanimals;

public class Animal {
    private String name;
    private  String gender;
    private int numOfLegs;
    private String type;
    private int picNumber;


    public Animal(String name, String gender, int numOfLegs, String type, int picNumber){
        this.name=name;
        this.gender=gender;
        this.numOfLegs=numOfLegs;
        this.type=type;
        this.picNumber=picNumber;
    }
    public int getPicNumber() {
        return this.picNumber;
    }

    public void setPicNumber(int picNumber) {
        this.picNumber = picNumber;
    }
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getNumOfLegs() {
        return this.numOfLegs;
    }

    public void setNumOfLegs(int numOfLegs) {
        this.numOfLegs = numOfLegs;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }



    @Override
    public String toString() {
        return "Animal{" +
                "name='" + this.name + '\'' +
                ", gender='" + this.gender + '\'' +
                ", numOfLegs=" + this.numOfLegs +
                ", type='" + this.type + '\'' +
                '}';
    }
}
