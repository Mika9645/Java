package com.example.myanimals;

public class Dog extends Animal{
    private int age;
    private String breed;
    private int weight;
    private String furColor;




    public Dog(String name, String gender, int numOfLegs, String type, int age, String breed, int weight, String furColor, int picNumber) {
        super(name, gender, numOfLegs, type, picNumber);

        this.age=age;
        this.breed=breed;
        this.weight=weight;
        this.furColor=furColor;
    }
    public int getAge() {
        return this.age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getBreed() {
        return this.breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public int getWeight() {
        return this.weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getFurColor() {
        return this.furColor;
    }

    public void setFurColor(String furColor) {
        this.furColor = furColor;
    }
    @Override
    public String toString() {
        return "a " + this.breed + " dog " + ", my name is " + this.getName() + " and my age is "+this.age;
    }



}
